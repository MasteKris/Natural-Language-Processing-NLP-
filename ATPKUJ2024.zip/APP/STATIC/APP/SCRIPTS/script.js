function displayResults(result) {
    var textToCheck = document.getElementById('tekst').value;
    var resultsSection = document.getElementById('resultsSection2');

    // Wy�wietlenie wynik�w analizy
    var analysisResults = "<p>Input Text: " + textToCheck + "</p>" +
        "<p>Word Count: " + result.word_count + "</p>" +
        "<p>Average Word Length: " + result.avg_word_length.toFixed(2) + "</p>" +
        "<p>Shortest Word: " + result.shortest_word + "</p>" +
        "<p>Longest Word: " + result.longest_word + "</p>";

    resultsSection.innerHTML = analysisResults;
}

function checkText() {
    var textToCheck = document.getElementById('tekst').value;

    // Use XMLHttpRequest to send a request to the 'detect_languages' view
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/detect_languages/?text=' + encodeURIComponent(textToCheck), true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            var results = JSON.parse(xhr.responseText);
            var resultHTML = 'Detected languages:<br>';
            results.languages.forEach(function (lang) {
                resultHTML += lang.lang + ' (' + (lang.prob * 100).toFixed(2) + '%)<br>';
            });
            document.getElementById('resultsSection').innerHTML = resultHTML;
        } else {
            console.error('Request failed. Returned status of ' + xhr.status);
        }
    };
    xhr.send(null);

    var text = document.getElementById('tekst').value;
    analyzeText(text).then(result => {
        displayResults(result);
    }).catch(error => {
        console.error('Error:', error);
    });
}

function checkAndAnalyzeText() {
    checkText(); // Wywo�ujemy funkcj� do sprawdzenia tekstu
    analyzeAndDisplayText(); // Wywo�ujemy funkcj� do analizy tekstu
}

function analyzeAndDisplayText() {
    var textToAnalyze = document.getElementById('tekst').value;
    console.log(textToAnalyze); // Dodaj ten wiersz, aby sprawdzi�, czy textToAnalyze zawiera oczekiwany tekst

    // Use XMLHttpRequest to send a request to the 'analyze_text' view
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/analyze_text/', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function () {
        if (xhr.status === 200) {
            var results = JSON.parse(xhr.responseText);
            console.log(results); // Dodajmy ten wiersz, aby wy�wietli� wyniki w konsoli
            displayResults(results); // Wywo�ujemy funkcj� do wy�wietlenia wynik�w
        } else {
            console.error('Request failed. Returned status of ' + xhr.status);
        }
    };
    var formData = 'tekst=' + encodeURIComponent(textToAnalyze);
    xhr.send(formData);
}


// Funkcja do analizy tekstu
function analyzeText(text) {
    return new Promise((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/analyze_text/', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            if (xhr.status === 200) {
                var results = JSON.parse(xhr.responseText);
                resolve(results);
            } else {
                reject('Request failed. Returned status of ' + xhr.status);
            }
        };
        var formData = 'tekst=' + encodeURIComponent(text);
        xhr.send(formData);
    });
}
