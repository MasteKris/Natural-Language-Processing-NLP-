"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render
from django.http import HttpRequest

def home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/index.html',
        {
            'title':'Home Page',
            'year':datetime.now().year,
        }
    )
#20
def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/contact.html',
        {
            'title':'Contact',
            'message':'Your contact page.',
            'year':datetime.now().year,
        }
    )

def about(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/about.html',
        {
            'title':'About',
            'message':'Your application description page.',
            'year':datetime.now().year,
        }
    )
from django.http import JsonResponse
from langdetect import detect
from django.views.decorators.csrf import csrf_exempt
import re

@csrf_exempt
def analyze_text(request):
    try:
        if request.method == 'POST':
            data = request.POST.get('tekst', '')
            if not isinstance(data, str):
                raise ValueError("Invalid input. Expected a string.")
            # Podzia� tekstu na s�owa
            words = re.findall(r'\b\w+\b', data)

            # Ilo�� s��w
            word_count = len(words)

            # �rednia d�ugo�� s�owa
            avg_word_length = sum(len(word) for word in words) / word_count if word_count > 0 else 0

            shortest_word = min(words, key=len)
            longest_word = max(words, key=len)

            # Wyniki
            results = {
                "word_count": word_count,
                "avg_word_length": avg_word_length,
                "shortest_word": shortest_word,
                "longest_word": longest_word,
            }

            return JsonResponse(results)  
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except ValueError as ve:
        return JsonResponse({'error': str(ve)})
    except Exception as e:
        return JsonResponse({'error': str(e)})

def detect_languages(request):
    try:
        text = request.GET.get('text', '')
        if not isinstance(text, str):
            raise ValueError("Invalid input. Expected a string.")

        # Tutaj mo�esz umie�ci� kod do detekcji j�zyk�w w tek�cie
        # Na przyk�ad:
        # languages = detect_langs(text)
        # results = [{'lang': lang.lang, 'prob': lang.prob} for lang in languages]

        # Dla uproszczenia zwracamy przyk�adowe dane
        results = {'languages': [{'lang': 'en', 'prob': 0.8}, {'lang': 'fr', 'prob': 0.5}]}
        return JsonResponse(results)
    except ValueError as ve:
        return JsonResponse({'error': str(ve)})
    except Exception as e:
        return JsonResponse({'error': str(e)})
