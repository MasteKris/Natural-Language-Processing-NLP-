"""
Package for $safeprojectname$.
"""
